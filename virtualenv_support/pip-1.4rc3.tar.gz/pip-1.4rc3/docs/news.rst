========
News
========

Next Release
============

Beta and final releases of 1.4 are planned for late 2013.


.. include:: ../CHANGES.txt

